<template>
    <router-view/>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
@import url('https://fonts.googleapis.com/css?family=Open+Sans:300,400,700');
@import url('https://unpkg.com/purecss@1.0.0/build/pure-min.css');
@import url('https://unpkg.com/purecss@1.0.0/build/grids-responsive-min.css');

body {
    font-family: 'Open Sans', sans-serif;
    padding: 1em;
}
</style>

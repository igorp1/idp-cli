<template>
  <div id="main-container">

        <!-- Placeholders for title and description -->
        <h1>project_name</h1>
        <p>project_description</p>

        <!-- REACTIVE COLUMNS FOR LAYOUT -->
        <!-- https://purecss.io/ -->
        <div class="pure-g">
            <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4">
                <h3>HERE'S</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            </div>
            <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4">
                <h3>SOME</h3>
                <p>Morbi quis neque nec ante maximus fringilla at eget nisi.</p>
            </div>
            <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4">
                <h3>REACTIVE</h3>
                <p>Mauris laoreet justo feugiat tincidunt vehicula.</p>
            </div>
            <div class="pure-u-1 pure-u-md-1-2 pure-u-lg-1-4">
                <h3>COLUMNS</h3>
                <p>Etiam congue libero dictum eleifend blandit.</p>
            </div>
        </div>

    </div>
</template>

<script>
export default {
  name: 'Home',
  data () {
    return {
      /* return your data here */
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1 {
  color: #42b983;
}
</style>
